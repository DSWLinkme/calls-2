export const APP_NAME = 'videocalling';
export const ACC_NAME = 'savinvadim';
